<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Arreglos y operaciones</title>
</head>
<body>
    <br><br>
    <center>
        <h2>Programa parta calcular numero mayor numero menor promedio</h2>
        <form action="operaciones.php" method="POST">
        <label id="n" for="numero">Señor usuario por favor ingrese los números</label><br>
        <input type="number" name="num" placeholder="numero" required><br><br>
        <input type="submit" id="m" name="enviar" value="generar">
    </center>
</form>
</body>
</html>