Inicio (despliegue de datos)
