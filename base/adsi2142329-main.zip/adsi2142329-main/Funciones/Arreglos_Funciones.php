<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Arreglos y Funciones</title>
</head>
<body>
    <br><br>
    <center>
        <h2>Calcular numero mayor, menor, promedio y mediana</h2>
        <form action="Funciones.php" method="POST">
        <label id="n" for="numero">Digite el número a generar</label><br>
        <input type="number" name="num" placeholder="numero" required><br><br>
        <input type="submit" id="m" name="enviar" value="generar">
    </center>
</form>
</body>
</html>